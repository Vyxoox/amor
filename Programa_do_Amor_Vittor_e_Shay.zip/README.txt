Suba o arquivo index.html no GitHub Pages ou Netlify.
Coloque sua musica.mp3 na mesma pasta.